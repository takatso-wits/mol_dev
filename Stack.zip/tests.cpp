#define CATCH_CONFIG_MAIN
#include "catch.hpp"
#include "Stack.h"

/* Note that Moodle will be using more comprehensive test cases */

TEST_CASE("EmptyStackSize"){
    Stack s;

    INFO("An empty stack should have size 0")
    REQUIRE(s.size() == 0);
}

TEST_CASE("PushPop"){
    Stack s;

    INFO("Pushing 1 and 2 onto the stack")
    s.push(1);
    s.push(2);
    REQUIRE(s.pop() == 2);
    INFO("Pushing 3 and 4 onto the stack")
    s.push(3);
    s.push(4);
    REQUIRE(s.pop() == 4);
    REQUIRE(s.pop() == 3);
    REQUIRE(s.pop() == 1);
}

TEST_CASE("Size"){
    Stack s;

    INFO("Pushing 1 and 2 onto the stack")
    s.push(1);
    s.push(2);
    REQUIRE(s.size() == 2);
    s.pop();
    INFO("Pushing 3 and 4 onto the stack")
    s.push(3);
    s.push(4);
    REQUIRE(s.size() == 3);
    s.pop();
    REQUIRE(s.size() == 2);
    s.pop();
    REQUIRE(s.size() == 1);
    s.pop();
    REQUIRE(s.size() == 0);
}

TEST_CASE("Peek"){
    Stack s;

    INFO("Pushing 1 and 2 onto the stack")
    s.push(1);
    s.push(2);
    REQUIRE(s.peek() == 2);
    s.pop();
    INFO("Pushing 3 and 4 onto the stack")
    s.push(3);
    s.push(4);
    REQUIRE(s.peek() == 4);
    s.pop();
    REQUIRE(s.peek() == 3);
    s.pop();
    REQUIRE(s.peek() == 1);
}
