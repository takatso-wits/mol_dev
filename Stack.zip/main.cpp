#include "Stack.h"

#include <iostream>

using namespace std;

int main(){

    // You can do whatever you want in this file to help
    //   check your code
    Stack s;
}
