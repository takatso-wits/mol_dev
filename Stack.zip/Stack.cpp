#include <vector>
#include "Stack.h"

using namespace std;

/*
 * Push an integer onto the stack
 */
void Stack::push(int value)
{

}

/*
 * Pop an integer off the stack and return it
 */
int Stack::pop()
{

}

/*
 * Return the int that's on top of the stack
 */
int Stack::peek() const
{

}

/*
 * Return the number of items on the stack
 */
int Stack::size() const
{

}
