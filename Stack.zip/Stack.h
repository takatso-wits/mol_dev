#ifndef _STACK_H
#define _STACK_H

// This line stops you from using the build in C++ stack
#define _GLIBCXX_STACK

#include <vector>

class Stack {
public:
    void push(int value);
    int pop();
    int peek() const;
    int size() const;

    std::vector<int> data;
};

#endif
